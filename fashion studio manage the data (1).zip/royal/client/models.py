from django.db import models

# Create your models here.
class userlogin(models.Model):
    username = models.CharField(max_length=40)
    password = models.CharField(max_length=20)
    utype = models.CharField(max_length=20)


class userhanuman(models.Model):
    Name = models.CharField(max_length=200)
    Email_id = models.CharField(max_length=200)
    utype = models.CharField(max_length=20)


class Storedetails(models.Model):
     storeid = models.CharField(max_length=200)
     sname = models.CharField(max_length=200)
     Frachaisi_id = models.CharField(max_length=200)
     Owner_id = models.CharField(max_length=200)
     GST_no = models.CharField(max_length=200)
     Licence_no = models.CharField(max_length=200)
     Start_date = models.CharField(max_length=200)
     Website = models.CharField(max_length=200)
     Landline_no = models.CharField(max_length=200)
     address = models.CharField(max_length=200)

class coursedetails(models.Model):
    courseid = models.CharField(max_length=20)
    coursename = models.CharField(max_length=50)
    department = models.CharField(max_length=40)
    marks = models.CharField(max_length=20)

class userdetails(models.Model):
    user_id = models.CharField(max_length=200)
    email_id = models.CharField(max_length=200)
    Mobileno = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    F_name = models.CharField(max_length=200)
    L_mame = models.CharField(max_length=200)
    credential_date = models.CharField(max_length=200)
    status = models.CharField(max_length=200)


class cartdetails(models.Model):
    cart_id = models.CharField(max_length=200)
    cateogery_id = models.CharField(max_length=200)
    product_id = models.CharField(max_length=200)
    user_id = models.CharField(max_length=200)
    order_date = models.CharField(max_length=200)
    date = models.CharField(max_length=200)
    Time = models.CharField(max_length=200)
    status = models.CharField(max_length=200)


class Billingdetails(models.Model):
    Order_id = models.CharField(max_length=200)
    Billing_id = models.CharField(max_length=200)
    Prouct_id = models.CharField(max_length=200)
    Quantity = models.CharField(max_length=200)
    Unit_price = models.CharField(max_length=200)
    Discount = models.CharField(max_length=200)
    Total = models.CharField(max_length=200)
    Date = models.CharField(max_length=200)
    Total_amount = models.CharField(max_length=200)
    status = models.CharField(max_length=200)

class Sizedetails(models.Model):
    Product_id = models.CharField(max_length=200)
    cateogery_id = models.CharField(max_length=200)
    Sizeno = models.CharField(max_length=200)
    In_cm = models.CharField(max_length=200)
    Country = models.CharField(max_length=200)

class Colordetails(models.Model):
    Cateogery_id = models.CharField(max_length=200)
    Product_id = models.CharField(max_length=200)
    Color_id = models.CharField(max_length=200)
    Name = models.CharField(max_length=200)
    Sample = models.FileField(upload_to='documents/')

class  About_item(models.Model):
    Cateogery_id = models.CharField(max_length=200)
    Product_id = models.CharField(max_length=200)
    wasn_type = models.CharField(max_length=200)
    Material_type = models.CharField(max_length=200)
    Handwasn = models.CharField(max_length=200)
    color_id = models.CharField(max_length=200)

class About_product(models.Model):
   Rating = models.CharField(max_length=200)
   review = models.CharField(max_length=200)

class ProductDetails(models.Model):
    Category_id = models.CharField(max_length=200)
    Brand_id = models.CharField(max_length=200)
    Style_id = models.CharField(max_length=200)
    Product_id = models.CharField(max_length=200)
    Description = models.CharField(max_length=200)
    size = models.CharField(max_length=200)
    Price = models.CharField(max_length=200)
    Offer = models.CharField(max_length=200)
    Dimension = models.CharField(max_length=200)
    Weight = models.CharField(max_length=200)
    Rating = models.CharField(max_length=200)
    Review = models.CharField(max_length=200)
    image = models.FileField(upload_to='documents/')

class Rating(models.Model):
    Product_id = models.CharField(max_length=200)
    Rating = models.CharField(max_length=200)
    User_id = models.CharField(max_length=200)
    date = models.CharField(max_length=200)

class Review(models.Model):
    Product_id = models.CharField(max_length=200)
    User_id = models.CharField(max_length=200)
    Date = models.CharField(max_length=200)
    Review_details = models.CharField(max_length=200)

class Style(models.Model):
    Style_id = models.CharField(max_length=200)
    Brand_id = models.CharField(max_length=200)
    Product_id = models.CharField(max_length=200)
    details = models.CharField(max_length=200)

class Brand(models.Model):
    Brand_id = models.CharField(max_length=200)
    Name = models.CharField(max_length=200)
    Company_name = models.CharField(max_length=200)
    Email_id = models.CharField(max_length=200)
    Contact_no = models.CharField(max_length=200)
    Helpline = models.CharField(max_length=200)
    Reg_no = models.CharField(max_length=200)


