"""royal URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import path

from client import (views)

urlpatterns = [
    path('admin/', admin.site.urls),
    url(r'^$', views.showindex, name='showindex'),
    url('login', views.login, name='login'),
    url('changepass', views.changepass, name='changepass'),
    url('inserthanuman', views.inserthanuman, name='inserthanuman'),

    url('insertcoursedetails_s', views.insertcoursedetails_s, name='insertcoursedetails_s'),
    url('coursedetails_view_ar', views.coursedetails_view_ar, name='coursedetails_view_ar'),
    url('coursedetails_view_ad', views.coursedetails_view_ad, name='coursedetails_view_ad'),


    url('insertStoredetails_ar', views.insertStoredetails_ar, name='insertStoredetails_ar'),
    url('Storedetails_view_s', views.Storedetails_view_s, name='Storedetails_view_s'),
    url('Storedetails_view_ad', views.Storedetails_view_ad, name='Storedetails_view_ad'),

    url('insertuserdetails_ar', views.insertuserdetails_ar, name='insertuserdetails_ar'),
    url('userdetails_view_ad', views.userdetails_view_ad, name='userdetails_view_ad'),
    url('userdetails_view_s', views.userdetails_view_s, name='userdetails_view_s'),

    url('insertcartdetails_ar', views.insertcartdetails_ar, name='insertcartdetails_ar'),
    url('cartdetails_view_s', views.cartdetails_view_s, name='cartdetails_view_s'),
    url('cartdetails_view_ad', views.cartdetails_view_ad, name='cartdetails_view_ad'),

    url('insertBillingdetails_s', views.insertBillingdetails_s, name='insertBillingdetails_s'),
    url('Billingdetails_view_ad', views.Billingdetails_view_ad, name='Billingdetails_view_ad'),
    url('Billingdetails_view_ar', views.Billingdetails_view_ar, name='Billingdetails_view_ar'),

    url('insertSizedetails_ar', views.insertSizedetails_ar, name='insertSizedetails_ar'),
    url('Sizedetails_view_s', views.Sizedetails_view_s, name='Sizedetails_view_s'),
    url('Sizedetails_view_ad', views.Sizedetails_view_ad, name='Sizedetails_view_ad'),

    url('insertColordetails_ar', views.insertColordetails_ar, name='insertColordetails_ar'),
    url('Colordetails_view_s', views.Colordetails_view_s, name='Colordetails_view_s'),
    url('Colordetails_view_ad', views.Colordetails_view_ad, name='Colordetails_view_ad'),

    url('insertAbout_item_s', views.insertAbout_item_s, name='insertAbout_item_s'),
    url('About_item_view_ad', views.About_item_view_ad, name='About_item_view_ad'),
    url('About_item_view_ar', views.About_item_view_ar, name='About_item_view_ar'),

    url('insertAbout_product_s', views.insertAbout_product_s, name='insertAbout_product_s'),
    url('About_product_view_ad', views.About_product_view_ad, name='About_product_view_ad'),
    url('About_product_view_ar', views.About_product_view_ar, name='About_product_view_ar'),

    url('insertProductDetails_s', views.insertProductDetails_s, name='insertProductDetails_s'),
    url('ProductDetails_view_ad', views.ProductDetails_view_ad, name='ProductDetails_view_ad'),
    url('ProductDetails_view_ar', views.ProductDetails_view_ar, name='ProductDetails_view_ar'),

    url('insertRating_ar', views.insertRating_ar, name='insertRating_ar'),
    url('Rating_view_s', views.Rating_view_s, name='Rating_view_s'),
    url('Rating_view_ad', views.Rating_view_ad, name='Rating_view_ad'),

    url('insertReview_ar', views.insertReview_ar, name='insertReview_ar'),
    url('Review_view_s', views.Review_view_s, name='Review_view_s'),
    url('Review_view_ad', views.Review_view_ad, name='Review_view_ad'),

    url('insertStyle_ar', views.insertStyle_ar, name='insertStyle_ar'),
    url('Style_view_s', views.Style_view_s, name='Style_view_s'),
    url('Style_view_ad', views.Style_view_ad, name='Style_view_ad'),

    url('insertBrand_s', views.insertBrand_s, name='insertBrand_s'),
    url('Brand_view_ad', views.Brand_view_ad, name='Brand_view_ad'),
    url('Brand_view_ar', views.Brand_view_ar, name='Brand_view_ar'),

    url('admin_home', views.admin_home, name='admin_home'),
    url('studio_home', views.studio_home, name='studio_home'),
    url('artist_home', views.artist_home, name='artist_home'),


 ]
