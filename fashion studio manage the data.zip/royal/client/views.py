from audioop import reverse

from django.shortcuts import render, redirect

from .models import coursedetails
from .models import userlogin
from .models import Storedetails
from .models import userdetails
from .models import cartdetails
from .models import Billingdetails
from .models import Sizedetails
from .models import Colordetails
from .models import About_item
from .models import About_product
from .models import ProductDetails
from .models import Rating
from .models import Review
from .models import Style
from .models import Brand
from .models import userhanuman






# Create your views here.

def showindex(request):
    return render(request, "index.html")

def showlogin(request):
    return render(request, "login.html")

def admin_home(request):
    return render(request, "admin_home.html")

def artist_home(request):
    return render(request, "artist_home.html")

def studio_home(request):
    return render(request, "studio_home.html")




def insertcoursedetails_s(request):
    if request.method == "POST":
        courseid = request.POST.get("t1")
        coursename = request.POST.get("t2")
        department = request.POST.get("t3")
        marks = request.POST.get("t4")

        coursedetails.objects.create(courseid=courseid, coursename=coursename, department=department, marks=marks)
        return render(request, "insertcoursedetails_s.html")
    return render(request, "insertcoursedetails_s.html")

def coursedetails_view_ar(request):
    userdict = coursedetails.objects.all()
    return render(request, 'coursedetails_view_ar.html', {'userdict': userdict})

def coursedetails_view_ad(request):
    userdict = coursedetails.objects.all()
    return render(request, 'coursedetails_view_ad.html', {'userdict': userdict})


def insertStoredetails_ar(request):
    if request.method == "POST":
        storeid = request.POST.get("t1")
        sname = request.POST.get("t2")
        Frachaisi_id = request.POST.get("t3")
        Owner_id = request.POST.get("t4")
        GST_no = request.POST.get("t5")
        Licence_no = request.POST.get("t6")
        Start_date = request.POST.get("t7")
        Website = request.POST.get("t8")
        Landline_no = request.POST.get("t9")
        address = request.POST.get("t10")

        Storedetails.objects.create(storeid=storeid, sname=sname, Frachaisi_id=Frachaisi_id, Owner_id=Owner_id ,GST_no=GST_no, Licence_no=Licence_no, Start_date=Start_date, Website=Website ,Landline_no=Landline_no, address=address)
        return render(request, "insertStoredetails_ar.html")
    return render(request, "insertStoredetails_ar.html")

def Storedetails_view_s(request):
    userdict = Storedetails.objects.all()
    return render(request, 'Storedetails_view_s.html', {'userdict': userdict})

def Storedetails_view_ad(request):
    userdict = Storedetails.objects.all()
    return render(request, 'Storedetails_view_ad.html', {'userdict': userdict})


def insertuserdetails_ar(request):
    if request.method == "POST":
        user_id = request.POST.get("t1")
        email_id = request.POST.get("t2")
        Mobileno = request.POST.get("t3")
        city = request.POST.get("t4")
        F_name = request.POST.get("t5")
        L_mame = request.POST.get("t6")
        credential_date = request.POST.get("t7")
        status = request.POST.get("t8")


        userdetails.objects.create(user_id=user_id, email_id=email_id, Mobileno=Mobileno, city=city, F_name=F_name, L_mame=L_mame, credential_date=credential_date, status=status )
        return render(request, "insertuserdetails_ar.html")
    return render(request, "insertuserdetails_ar.html")

def userdetails_view_ad(request):
    userdict = userdetails.objects.all()
    return render(request,'userdetails_view_ad.html',{'userdict': userdict})

def userdetails_view_s(request):
    userdict = userdetails.objects.all()
    return render(request,'userdetails_view_s.html',{'userdict': userdict})


def insertcartdetails_ar(request):
    if request.method == "POST":
        cart_id = request.POST.get("t1")
        cateogery_id = request.POST.get("t2")
        product_id = request.POST.get("t3")
        user_id = request.POST.get("t4")
        order_date = request.POST.get("t5")
        date = request.POST.get("t6")
        Time = request.POST.get("t7")
        status = request.POST.get("t8")

        cartdetails.objects.create(cart_id=cart_id, cateogery_id=cateogery_id, product_id=product_id, user_id=user_id, order_date=order_date,
                                   date=date, Time=Time, status=status)
        return render(request, "insertcartdetails_ar.html")
    return render(request, "insertcartdetails_ar.html")

def cartdetails_view_s(request):
    userdict = cartdetails.objects.all()
    return render(request, 'cartdetails_view_s.html',{'userdict': userdict})

def cartdetails_view_ad(request):
    userdict = cartdetails.objects.all()
    return render(request, 'cartdetails_view_ad.html',{'userdict': userdict})



def insertBillingdetails_s(request):
    if request.method == "POST":
        Order_id = request.POST.get("t1")
        Billing_id = request.POST.get("t2")
        Prouct_id = request.POST.get("t3")
        Quantity = request.POST.get("t4")
        Unit_price = request.POST.get("t5")
        Discount = request.POST.get("t6")
        Total = request.POST.get("t7")
        Date = request.POST.get("t8")
        Total_amount = request.POST.get("t9")
        status = request.POST.get("t10")

        Billingdetails.objects.create(Order_id=Order_id, Billing_id=Billing_id, Prouct_id=Prouct_id, Quantity=Quantity, Unit_price=Unit_price, Discount=Discount, Total=Total, Date=Date,  Total_amount=Total_amount, status=status)
        return render(request, "insertBillingdetails_s.html")
    return render(request, "insertBillingdetails_s.html")

def Billingdetails_view_ad(request):
    userdict = Billingdetails.objects.all()
    return render(request, 'Billingdetails_view_ad.html',{'userdict': userdict})

def Billingdetails_view_ar(request):
    userdict = Billingdetails.objects.all()
    return render(request, 'Billingdetails_view_ar.html',{'userdict': userdict})

def insertSizedetails_ar(request):
    if request.method == "POST":
        Product_id = request.POST.get("t1")
        cateogery_id = request.POST.get("t2")
        Sizeno = request.POST.get("t3")
        In_cm = request.POST.get("t4")
        Country = request.POST.get("t5")

        Sizedetails.objects.create(Product_id=Product_id, cateogery_id=cateogery_id, Sizeno=Sizeno, In_cm=In_cm,  Country=Country )
        return render(request, "insertSizedetails_ar.html")
    return render(request, "insertSizedetails_ar.html")

def Sizedetails_view_s(request):
    userdict = Sizedetails.objects.all()
    return render(request, 'Sizedetails_view_s.html',{'userdict': userdict})

def Sizedetails_view_ad(request):
    userdict = Sizedetails.objects.all()
    return render(request, 'Sizedetails_view_ad.html',{'userdict': userdict})

def insertColordetails_ar(request):
    if request.method == "POST":
        Cateogery_id = request.POST.get("t1")
        Product_id = request.POST.get("t2")
        Color_id = request.POST.get("t3")
        Name = request.POST.get("t4")
        Sample = request.POST.get("t5")

        Colordetails.objects.create(Cateogery_id=Cateogery_id, Product_id=Product_id, Color_id=Color_id, Name=Name,  Sample=Sample )
        return render(request, "insertColordetails_ar.html")
    return render(request, "insertColordetails_ar.html")

def Colordetails_view_s(request):
    userdict = Colordetails.objects.all()
    return render(request, 'Colordetails_view_s.html',{'userdict': userdict})

def Colordetails_view_ad(request):
    userdict = Colordetails.objects.all()
    return render(request, 'Colordetails_view_ad.html',{'userdict': userdict})

def insertAbout_item_s(request):
    if request.method == "POST":
        Cateogery_id = request.POST.get("t1")
        Product_id = request.POST.get("t2")
        wasn_type = request.POST.get("t3")
        Material_type = request.POST.get("t4")
        Handwasn = request.POST.get("t5")
        color_id = request.POST.get("t6")

        About_item.objects.create(Cateogery_id=Cateogery_id, Product_id=Product_id, wasn_type=wasn_type, Material_type=Material_type,  Handwasn=Handwasn ,color_id=color_id )
        return render(request, "insertAbout_item_s.html")
    return render(request, "insertAbout_item_s.html")

def About_item_view_ad(request):
    userdict = About_item.objects.all()
    return render(request, 'About_item_view_ad.html',{'userdict': userdict})

def About_item_view_ar(request):
    userdict = About_item.objects.all()
    return render(request, 'About_item_view_ar.html',{'userdict': userdict})

def insertAbout_product_s(request):
    if request.method == "POST":
        Rating = request.POST.get("t1")
        review = request.POST.get("t2")


        About_product.objects.create(Rating=Rating, review=review)
        return render(request, "insertAbout_product_s.html")
    return render(request, "insertAbout_product_s.html")

def About_product_view_ad(request):
    userdict = About_product.objects.all()
    return render(request, 'About_product_view_ad.html',{'userdict': userdict})

def About_product_view_ar(request):
    userdict = About_product.objects.all()
    return render(request, 'About_product_view_ar.html',{'userdict': userdict})

def insertProductDetails_s(request):
    if request.method == "POST":
        Category_id = request.POST.get("t1")
        Brand_id = request.POST.get("t2")
        Style_id = request.POST.get("t3")
        Product_id = request.POST.get("t4")
        Description = request.POST.get("t5")
        size = request.POST.get("t6")
        Price = request.POST.get("t7")
        Offer = request.POST.get("t8")
        Dimension = request.POST.get("t9")
        Weight = request.POST.get("t10")
        Rating = request.POST.get("t11")
        Review = request.POST.get("t12")
        image = request.POST.get("t13")

        ProductDetails.objects.create(Category_id=Category_id, Brand_id=Brand_id, Style_id=Style_id, Product_id=Product_id ,Description=Description, size=size, Price=Price, Offer=Offer ,Dimension=Dimension, Weight=Weight , Rating=Rating,Review=Review,image=image)
        return render(request, "insertProductDetails_s.html")
    return render(request, "insertProductDetails_s.html")

def ProductDetails_view_ad(request):
    userdict = ProductDetails.objects.all()
    return render(request, 'ProductDetails_view_ad.html',{'userdict': userdict})

def ProductDetails_view_ar(request):
    userdict = ProductDetails.objects.all()
    return render(request, 'ProductDetails_view_ar.html',{'userdict': userdict})


def insertRating_ar(request):
    if request.method == "POST":
        Product_id = request.POST.get("t1")
        Rating = request.POST.get("t2")
        User_id = request.POST.get("t3")
        date = request.POST.get("t4")

        Rating.objects.create(Product_id=Product_id, Rating=Rating, User_id=User_id, date=date)
        return render(request, "insertRating_ar.html")
    return render(request, "insertRating_ar.html")

def Rating_view_s(request):
    userdict = Rating.objects.all()
    return render(request, 'Rating_view_s.html', {'userdict': userdict})

def Rating_view_ad(request):
    userdict = Rating.objects.all()
    return render(request, 'Rating_view_ad.html', {'userdict': userdict})


def insertReview_ar(request):
    if request.method == "POST":
        Product_id = request.POST.get("t1")
        User_id = request.POST.get("t2")
        Date = request.POST.get("t3")
        Review_details = request.POST.get("t4")

        Review.objects.create(Product_id=Product_id, User_id=User_id, Date=Date, Review_details=Review_details)
        return render(request, "insertReview_ar.html")
    return render(request, "insertReview_ar.html")

def Review_view_s(request):
    userdict = Review.objects.all()
    return render(request, 'Review_view_s.html',{'userdict': userdict})

def Review_view_ad(request):
    userdict = Review.objects.all()
    return render(request, 'Review_view_s.html',{'userdict': userdict})

def insertStyle_ar(request):
    if request.method == "POST":
        Style_id = request.POST.get("t1")
        Brand_id = request.POST.get("t2")
        Product_id = request.POST.get("t3")
        details = request.POST.get("t4")

        Style.objects.create(Style_id=Style_id, Brand_id=Brand_id, Product_id=Product_id, details=details )
        return render(request, "insertStyle_ar.html")
    return render(request, "insertStyle_ar.html")

def Style_view_s(request):
    userdict = Style.objects.all()
    return render(request,'Style_view_s.html',{'userdict': userdict})

def Style_view_ad(request):
    userdict = Style.objects.all()
    return render(request, 'Style_view_ad.html',{'userdict': userdict})


def insertBrand_s(request):
    if request.method == "POST":
        Brand_id = request.POST.get("t1")
        Name = request.POST.get("t2")
        Company_name = request.POST.get("t3")
        Email_id = request.POST.get("t4")
        Contact_no = request.POST.get("t5")
        Helpline = request.POST.get("t6")
        Reg_no = request.POST.get("t7")

        Brand.objects.create(Brand_id=Brand_id, Name=Name, Company_name=Company_name, Email_id=Email_id,  Contact_no=Contact_no ,Helpline=Helpline, Reg_no=Reg_no )
        return render(request, "insertBrand_s.html")
    return render(request, "insertBrand_s.html")

def Brand_view_ad(request):
    userdict = Brand.objects.all()
    return render(request, 'Brand_view_ad.html',{'userdict': userdict})

def Brand_view_ar(request):
    userdict = Brand.objects.all()
    return render(request, 'Brand_view_ar.html',{'userdict': userdict})

def login(request):
    if request.method == "POST":
        username = request.POST.get('t1')
        request.session['username'] = username
        password = request.POST.get('t2')

        ucheck = userlogin.objects.filter(username=username).count()
        if ucheck >= 1:
            udata = userlogin.objects.get(username=username)
            upass = udata.password
            utype = udata.utype
            if upass == password:
                if utype == 'admin':
                    return render(request, 'admin_home.html')
                if utype == 'studio':
                    return render(request, 'studio_home.html')
                if utype == 'artist':
                    return render(request, 'artist_home.html')
            else:
                return render(request, 'login.html', {'msg': 'invalid password'})
        else:
            return render(request, 'login.html', {'msg': 'invalid username'})
    return render(request, 'login.html')

def inserthanuman(request):
    if request.method == "POST":
        Name = request.POST.get("t1")
        request.session['Name'] = Name
        Email_id = request.POST.get("t2")
        utype = request.POST.get("t3")
        userhanuman.objects.create(Name=Name, Email_id=Email_id,utype=utype)
        ucheck = userhanuman.objects.filter(username=Email_id).count()
        if ucheck >= 1:
            udata = userhanuman.objects.get(username=Email_id)
            upass = udata.Email_id
            utype = udata.utype
            if upass == Email_id:
                if utype == 'studio':
                    return render(request, 'studio_home.html')
            else:
                 return render(request, 'inserthanuman.html', {'msg': 'invalid email'})
        else:
            return render(request, 'inserthanuman.html', {'msg': 'invalid Name'})
    return render(request, "inserthanuman.html")


def changepass(request):
    if request.method == 'POST':
        uname = request.session['username']
        currentpass = request.POST.get('t1', '')
        newpass = request.POST.get('t2', '')
        confirmpass = request.POST.get('t3', '')

        ucheck = userlogin.objects.filter(username=uname).values()
        for a in ucheck:
            u = a['username']
            p = a['password']
            if u == uname and currentpass == p:
                if newpass == confirmpass:
                    userlogin.objects.filter(username=uname).update(password=newpass)

                else:
                    return render(request, 'changepassword.html',{'msg': 'both the usename and password are incorrect'})
            else:
                return render(request, 'changepassword.html',{'msg': 'invalid username'})
    return render(request, 'changepassword.html')